import React from 'react'

const SettingsPage = () => {
  return (
    <div className='settings-page'>
        <header>
            <h1>Settings</h1>
        </header>
        <div className='change-password'>
            
        </div>
        <div className='delete-account'>

        </div>
    </div>
  )
}

export default SettingsPage